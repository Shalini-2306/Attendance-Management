var BASEURL='https://laravel.dev/laravel/blog/public';//window.location.href;
$(document).ready(function() {
	var usertable= {};
	var attend_date=$('#date').val();
	var BASEURL='https://laravel.dev/laravel/blog/public';//window.location.href;
	setTimeout(function() {
		usertable.ajax.url(BASEURL+'/getUserAjaxURL/'+attend_date).load();
	},1000);
	
	
	$( function() {
    
    $("#datepicker").datepicker({
    constrainInput: true,
	 showOn: 'button',
	 buttonText: "Choose Date",
	onSelect: function() { 
	var dateObject = $("#datepicker").datepicker('getDate');
	var selectDate=$.datepicker.formatDate('yy-mm-dd', dateObject);
	setTimeout(function() {
		usertable.ajax.url(BASEURL+'/getUserAjaxURL/'+selectDate).load();
	},500);
}
	
  } ).next(".ui-datepicker-trigger").addClass("btn btn-success  btn-sm success picker");
});
	
	
 $('#refresh_user').on("click", function(event) {
		 var attend_date=$('#date').val();
		 setTimeout(function() {
			usertable.ajax.url(BASEURL+'/getUserAjaxURL/'+attend_date).load();
		},500);
});
	
	
	
	var usertable = $('#user_table').DataTable( {
        responsive: true,
   } );
 
    new $.fn.dataTable.FixedHeader( table );



} );
