<html>
<head>
</head>
<body><p>Hi, Please verify email by click on link! <a href="{{ $link }}" target="blank">Click here</a></p></body>
</html>
