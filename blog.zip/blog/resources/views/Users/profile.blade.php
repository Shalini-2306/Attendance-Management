@extends('layout.user')
@section('title','View Profile')
@section('content')
@section('pagetitle', 'Profile')
<div class="row">
	<div class="col-xl-12 col-lg-12">
		<div class="card shadow mb-4">
		<div class="card-header py-3">
		  <h6 class="m-0 font-weight-bold text-primary">My Profile</h6>
		</div>
		<div class="card-body">
		 <p>My Profile Details:</p>
		 <p><b>Name:</b> {{$user->user_name}}</p>
		 <p><b>Email:</b> {{$user->email}}</p>
		</div>
	  </div>
	</div>
</div>
@endsection

