@extends('layout.signin')
@section('title','Login/Sigin Up')
@section('description','Please login here..')
@section('content')


@if(Session::has('sus_msg'))
<div class="alert alert-success">
 {{ Session::get('sus_msg') }}
</div>
@endif
@if(Session::has('ere_msg'))
<div class="alert alert-danger">
 {{ Session::get('ere_msg') }}
</div>
@endif
<div class="login-reg-panel">
	<div class="login-info-box">
		<h2>Have an account?</h2>
		<p>Please Login Here...</p>
		<label id="label-register" for="log-reg-show">Login</label>
		<input type="radio" name="active-log-panel" id="log-reg-show"  checked="checked" class="current_check">
	</div>
						
	<div class="register-info-box">
		<h2>Don't have an account?</h2>
		<p>Please Create An Account Here...</p>
		<label id="label-login" for="log-login-show">Register</label>
		<input type="radio" name="active-log-panel" id="log-login-show" class="current_check">
	</div>
						
	<div class="white-panel">
		<div class="login-show">
			<h2>LOGIN</h2>
			{!! Form::open(array('url' => 'login','id'=>'userlogin' ,'method'=>'post', 'name'=>'login-form')) !!}
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
			{{ Form::email('useremail','',array('class'=>'', 'id'=>'useremail', 'autocomplete'=>'off', 'placeholder'=>'Email', 'required')) }}
			<input type="password" name="pswd" placeholder="Password" required>
			{{ Form::submit('Login','',array('class'=>'button', 'id'=>'login', 'autocomplete'=>'off')) }}
			{!! Form::close() !!}
		</div>
		<div class="register-show">
			<h2>REGISTER</h2>
			{!! Form::open(array('url' => 'signup','id'=>'usersignup' ,'method'=>'post', 'name'=>'signup-form')) !!}
			<input type="hidden" name="_token" value="{{ csrf_token() }}">
			{{ Form::text('user_name','',array('class'=>'', 'id'=>'user_name', 'autocomplete'=>'off', 'placeholder'=>'User Name', 'required')) }}
			{{ Form::email('user_email','',array('class'=>'', 'id'=>'user_email', 'autocomplete'=>'off', 'placeholder'=>'Email', 'required')) }}
			<input type="password" name="pswd" placeholder="Password" required>
			{{ Form::submit('Register','',array('class'=>'button', 'id'=>'register', 'autocomplete'=>'off')) }}
			{!! Form::close() !!}
			
		</div>
	</div>
</div>
@endsection
