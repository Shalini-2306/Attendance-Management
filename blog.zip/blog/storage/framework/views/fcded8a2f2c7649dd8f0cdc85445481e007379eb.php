<?php $__env->startSection('title','View Users'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pagetitle', 'Users'); ?>
<style>
	.row
	{
		width:100% !important;
	}
	table.dataTable {
		border-collapse: collapse !import;
}
.dataTables_info
{
	display:none;
}
#user_table_paginate
{
	display:none;
}
.refresh, .ui-datepicker-trigger{
	float: right;
	margin-left: 10px;
}
</style>
<div class="row">
	<div class="col-xl-12 col-lg-12">
		<?php if(Session::has('att_sus_msg')): ?>
		<div class="alert alert-success">
		 <?php echo e(Session::get('att_sus_msg')); ?>

		</div>
		<?php endif; ?>
		<?php if(Session::has('att_ere_msg')): ?>
		<div class="alert alert-danger">
		 <?php echo e(Session::get('att_ere_msg')); ?>

		</div>
		<?php endif; ?>
		<div class="card shadow mb-4">
		<div class="card-header py-3">
		  <h6 class="m-0 font-weight-bold text-primary">Users
		  <input type="text" id="datepicker" style="display: none;">
		  <button type="button" class="btn btn-info  btn-sm info refresh" data-spinner-color="#4D4D4D" data-size="l" data-style="zoom-in" id="refresh_user" data-toggle="popover"  data-content="Refresh">Refresh</button>
		</h6>
		</div>
		<input type="hidden" id="date" value="<?php echo e(date('Y-m-d')); ?>"
		<div class="card-body">
			<table class="table table-striped table-bordered nowrap" style="width:100%"  id="user_table">
				<thead>
					<tr>
						<th><b>Name</b></th>
						<th><b>Email </b></th>
						<th><b>Attendance </b></th>
					</tr>
				</thead>
				<tbody>
					
				</tbody>
			</table>
		</div>
	  </div>
	</div>
</div>

<?php $__env->stopSection(); ?>
 

<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>