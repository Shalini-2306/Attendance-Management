<?php $__env->startSection('title','View Profile'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pagetitle', 'Profile'); ?>
<div class="row">
	<div class="col-xl-12 col-lg-12">
		<div class="card shadow mb-4">
		<div class="card-header py-3">
		  <h6 class="m-0 font-weight-bold text-primary">My Profile</h6>
		</div>
		<div class="card-body">
		 <p>My Profile Details:</p>
		 <p><b>Name:</b> <?php echo e($user->user_name); ?></p>
		 <p><b>Email:</b> <?php echo e($user->email); ?></p>
		</div>
	  </div>
	</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>