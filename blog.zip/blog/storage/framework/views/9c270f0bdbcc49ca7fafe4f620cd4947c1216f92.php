<!DOCTYPE HTML>
<html lang="en">
	<head>
		<title> <?php echo $__env->yieldContent('title'); ?> </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
		<!-----CSS----------------------------------------------->
		<link rel="stylesheet" href="<?php echo e(url('css')); ?>/bootstrap.min.css"/>
		<link rel="stylesheet" href="<?php echo e(url('css')); ?>/style.css" />
		<link rel="stylesheet" href="<?php echo e(url('css')); ?>/font-awesome.min.css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	</head>
	<body>
		<?php echo $__env->yieldContent('content'); ?>
		<script src="<?php echo e(url('js')); ?>/jquery.min.js"></script>
		<script src="<?php echo e(url('js')); ?>/bootstrap.min.js"></script>
		<script src="<?php echo e(url('js')); ?>/script.js"></script>
	</body>
</html>
