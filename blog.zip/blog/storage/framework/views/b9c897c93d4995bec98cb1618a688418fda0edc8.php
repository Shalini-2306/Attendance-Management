<?php $__env->startSection('title','Login/Sigin Up'); ?>
<?php $__env->startSection('description','Please login here..'); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('sus_msg')): ?>
<div class="alert alert-success">
 <?php echo e(Session::get('sus_msg')); ?>

</div>
<?php endif; ?>
<?php if(Session::has('ere_msg')): ?>
<div class="alert alert-danger">
 <?php echo e(Session::get('ere_msg')); ?>

</div>
<?php endif; ?>
<div class="login-reg-panel">
	<div class="login-info-box">
		<h2>Have an account?</h2>
		<p>Please Login Here...</p>
		<label id="label-register" for="log-reg-show">Login</label>
		<input type="radio" name="active-log-panel" id="log-reg-show"  checked="checked" class="current_check">
	</div>
						
	<div class="register-info-box">
		<h2>Don't have an account?</h2>
		<p>Please Create An Account Here...</p>
		<label id="label-login" for="log-login-show">Register</label>
		<input type="radio" name="active-log-panel" id="log-login-show" class="current_check">
	</div>
						
	<div class="white-panel">
		<div class="login-show">
			<h2>LOGIN</h2>
			<?php echo Form::open(array('url' => 'login','id'=>'userlogin' ,'method'=>'post', 'name'=>'login-form')); ?>

			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<?php echo e(Form::email('useremail','',array('class'=>'', 'id'=>'useremail', 'autocomplete'=>'off', 'placeholder'=>'Email', 'required'))); ?>

			<input type="password" name="pswd" placeholder="Password" required>
			<?php echo e(Form::submit('Login','',array('class'=>'button', 'id'=>'login', 'autocomplete'=>'off'))); ?>

			<?php echo Form::close(); ?>

		</div>
		<div class="register-show">
			<h2>REGISTER</h2>
			<?php echo Form::open(array('url' => 'signup','id'=>'usersignup' ,'method'=>'post', 'name'=>'signup-form')); ?>

			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<?php echo e(Form::text('user_name','',array('class'=>'', 'id'=>'user_name', 'autocomplete'=>'off', 'placeholder'=>'User Name', 'required'))); ?>

			<?php echo e(Form::email('user_email','',array('class'=>'', 'id'=>'user_email', 'autocomplete'=>'off', 'placeholder'=>'Email', 'required'))); ?>

			<input type="password" name="pswd" placeholder="Password" required>
			<?php echo e(Form::submit('Register','',array('class'=>'button', 'id'=>'register', 'autocomplete'=>'off'))); ?>

			<?php echo Form::close(); ?>

			
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>