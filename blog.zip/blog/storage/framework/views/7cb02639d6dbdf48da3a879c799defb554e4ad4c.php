<?php $__env->startSection('title','Mark Attendance'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('pagetitle', 'Attendance'); ?>
<div class="row">
	<div class="col-xl-12 col-lg-12">
		<?php if(Session::has('att_sus_msg')): ?>
		<div class="alert alert-success">
		 <?php echo e(Session::get('att_sus_msg')); ?>

		</div>
		<?php endif; ?>
		<?php if(Session::has('att_ere_msg')): ?>
		<div class="alert alert-danger">
		 <?php echo e(Session::get('att_ere_msg')); ?>

		</div>
		<?php endif; ?>
		<div class="card shadow mb-4">
		<div class="card-header py-3">
		  <h6 class="m-0 font-weight-bold text-primary">Attendance</h6>
		</div>
		<div class="card-body">
		<?php if($status == 0): ?>
		 <p>Please Mark today attendance</p>
		 <?php echo Form::open(array('url' => 'mark_attendance','id'=>'markattend' ,'method'=>'post', 'name'=>'attend-form')); ?>

		 <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		 <input type="hidden" name="attendance_id" value="Session::get('user_id')">
		 <?php echo e(Form::submit('Mark Attendance','',array('class'=>'d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm', 'id'=>'mark'))); ?>

		 <?php echo Form::close(); ?>

		 <?php else: ?>
		 <div class="alert alert-success">You have been successfully marked your attendance.</div>
		 <?php endif; ?>
		</div>
	  </div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>