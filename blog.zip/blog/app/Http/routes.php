<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
	
   // return view('welcome');
   return view('Users/login');
});


Route::post('login', 'UsersController@login');
Route::post('signup', 'UsersController@signup');
Route::get('/profile', 'UsersController@dashboard');
Route::get('/attendance', 'UsersController@attendance');
Route::get('/view_user', 'UsersController@viewUser');
Route::get('/verify/{id}', 'UsersController@verify');
Route::get('/getUserAjaxURL/{date}', 'UsersController@getUserAjaxURL');
Route::post('mark_attendance', 'UsersController@markattendance');
Route::get('logout', 'UsersController@logout');
