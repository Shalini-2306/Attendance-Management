<?php

namespace App\Http\Controllers;
error_reporting(-1); 
use DB;
use Input;
use Illuminate\Http\Request;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Mail;
use Session;
use Redirect;
use App\Http\Requests;
use App\User;

use Cookie;

class UsersController extends Controller
{
	public function home()
	{
		return view('Users/login');
	}
	public function login(Request $r)
	{
		 $pswd=$r->pswd;
		$email=$r->useremail;
		$email_exists = DB::table('users')->where('email', $email)->first();
		if(!empty($email_exists))
		{
			$verify=password_verify($pswd, $email_exists->password);
			if(!empty($email_exists) && $verify ==1)
			{
				$id=$email_exists->id;
				$user_name=$email_exists->user_name;
				$user_type=$email_exists->user_type;
				Session::set('user_id',$id);
				Session::set('user_name',$user_name);
				Session::set('user_type',$user_type);	
				Session::flash('sus_msg', 'Login successfully.'); 
				return Redirect::to('/profile');
			}
			else
			{
				Session::flash('ere_msg', 'Email or password does not match!'); 
				return Redirect::to('/');
			}
		}
		else
		{
			Session::flash('ere_msg', 'Email not exists'); 
			return Redirect::to('/');
		}
	}
	public function signup(Request $r)
	{
		$user_name=$r->user_name;
		$email=$r->user_email;
		$pswd=$r->pswd;
		$existData=DB::table('users')->where('email', $email)->first();
		if(empty($existData))
		{
			$insertid=DB::table('users')->insertGetId([
			'user_name' => $user_name,
			'user_type' => 2,
			'email' => $email,
			'password' => bcrypt($pswd),
			]);
			if($insertid !='')
			{
				//~ Session::set('user_id',$insertid);
				//~ Session::set('user_name',$user_name);
				//~ Session::set('user_type',2);
				$User=new User;
				$currentURL = url('/');
				$link=$currentURL.'/verify/'.$insertid;
				$User->email = $email;
				$data = [
				'link' => $link,
				];
			
				Mail::send('Mail/mail', $data, function($message) use($User) {
					$message->to($User->email, $User->email)->subject
					('Email verification');
					 $message->from('test@gmail.com','test@gmail.com');
				}); 
				Session::flash('sus_msg', 'Registration successful. We ahve send a link on your register email id, Please Verify your email.'); 
				return Redirect::to('/');
				
			}
			else
			{
				Session::flash('ere_msg', 'Something went wrong!');
				return Redirect::to('/');
			}
			
		}
		else
		{
			Session::flash('ere_msg', 'Email already exists!');
			return Redirect::to('/');
		}
		
	}
	public function verify($id)
	{
		DB::table('users')->where('id', $id)->update(['verify'=>1]);
		return Redirect::to('/');
	}
	public function markattendance()
	{
		if($this->checksession() ==1)
		{
			$userId = Session::get('user_id');
			$userType = Session::get('user_type');
			if($userType !='' && $userType == 2)
			{
				$user_exists = DB::table('users')->where('id', $userId)->where('user_type', $userType)->first();
				if(!empty($user_exists))
				{
					$insertid=DB::table('attendance')->insertGetId([
					'user_id' => $userId,
					'attendance_date' => date('Y-m-d'),
					'datetime' => date('Y-m-d H:i:s'),
					]);
					Session::flash('att_sus_msg', 'Attendance marked successfully.');
					return Redirect::to('/attendance');
				}
				else
				{
					Session::flash('att_ere_msg', 'User not exist!');
					return Redirect::to('/attendance');
				}
			}
			else
			{
				Session::flash('att_ere_msg', 'User not authorized!');
				return Redirect::to('/attendance');
			}
		}
		else
		{
			Session::flash('att_ere_msg', 'Your session has been expired, Please login to continue!');
			return Redirect::to('/');
		}
	}
	public function dashboard()
	{
		if($this->checksession() == 1)
		{
			$userId = Session::get('user_id');
			$userType = Session::get('user_type');
			$user_exists = DB::table('users')->where('id', $userId)->where('user_type', $userType)->first();
			return view('Users/profile')->with('user', $user_exists);
		}
		else
		{
			Session::flash('att_ere_msg', 'Your session has been expired, Please login to continue!');
			return Redirect::to('/');
		}
	}
	public function attendance()
	{
		if($this->checksession() == 1)
		{
			$userId = Session::get('user_id');
			$userType = Session::get('user_type');
			$currentDate=date('Y-m-d');
			$status=0;
			$attendance_exists = DB::table('attendance')->where('user_id', $userId)->where('attendance_date', $currentDate)->first();
			//print_r($attendance_exists);exit;
			if(!empty($attendance_exists))
			{
				$status=1;
			}
			return view('Users/attendance')->with('status', $status);
		}
		else
		{
			Session::flash('att_ere_msg', 'Your session has been expired, Please login to continue!');
			return Redirect::to('/');
		}
	}
	public function viewUser()
	{
		if($this->checksession() == 1)
		{
			$userId = Session::get('user_id');
			$userType = Session::get('user_type');
			if($userType ==1)
			{
				return view('Admin/view-user');
			}
			else
			{
				Session::flash('att_ere_msg', 'Your session has been expired, Please login to continue!');
				return Redirect::to('/');
			}
			
		}
		else
		{
			Session::flash('att_ere_msg', 'Your session has been expired, Please login to continue!');
			return Redirect::to('/');
		}
	}
	public function getUserAjaxURL($date)
	{
		if($this->checksession() == 1)
		{
			$currentDate=$date;
			$attendance = DB::table('attendance')->where('attendance_date', $currentDate)->get();
			$records['data'] = array();	
			if(isset($attendance))
			{
				foreach($attendance as $attend)
				{
					$user = array();
					$userData=DB::table('users')->where('id', $attend->user_id)->first();
					array_push($user, $userData->user_name);
					array_push($user, $userData->email);
					array_push($user, $attend->attendance_date);
					$records["data"][] = $user;
				}
			}
			echo json_encode($records);
		}
		else
		{
			Session::flash('att_ere_msg', 'Your session has been expired, Please login to continue!');
			return Redirect::to('/');
		}
	}
	public function checksession()
	{
		$userId = Session::get('user_id');
		if($userId != '' || $userId != NULL)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	public function logout()
    {
        Session::forget('user_id');
        Session::forget('user_name');
        Session::forget('user_type');
        return Redirect::to('/');
    }	
}

